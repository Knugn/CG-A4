Computer Graphics, Assignment 4
=============================================

Follow the build instructions from Assignment 2, but replace
ASSIGNMENT2_ROOT with ASSIGNMENT4_ROOT.

To enable the AntTweakBar panel, you need to go into the CMakeLists.txt
file and uncomment the AntTweakBar section. The assignment code contains
necessary code for initializing AntTweakBar and performing some event
handling. For the bonus task, you have to extend this code and add your
own variables and callbacks (see the instructions).
